package com.minesweepergame;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;

public class InputHandler implements InputProcessor {


    @Override
    public boolean keyDown(int keycode) {
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        if (keycode == Input.Keys.M)
        {
            Vars.gameScene = null;
            Vars.game.setScreen(Vars.menuScene);
        }
        if (keycode == Input.Keys.R && Vars.gameScene != null)
        {
            Vars.clearVars();
            Vars.game.setScreen(new GameScene());
        }
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        if (Vars.gameState == 0)
        {
            if (button == Input.Buttons.LEFT)
            {
                Grid g = Funcs.getGridOnMouse();
                if (g != null && g.flagged == false && g.opened == false)
                {
                    if (Vars.firstClickGrid == null)
                    {
                        Vars.firstClickGrid = g;
                        Vars.gameScene.placeBombs();
                    }
                    Funcs.BFSOpenFrom(g);
                    if (Vars.gameState == 0 && Funcs.checkIfWon())
                    {
                        Funcs.win();
                    }
                }
            }
            else if (button == Input.Buttons.RIGHT)
            {
                Grid g = Funcs.getGridOnMouse();
                if (g != null && g.opened == false)
                {
                    if (g.flagged)
                    {
                        g.flagged = false;
                        g.unknown = true;
                        Vars.flaggedCount--;
                    }
                    else if (g.unknown)
                    {
                        g.unknown = false;
                    }
                    else
                    {
                        g.flagged = true;
                        Vars.flaggedCount++;
                    }
                }
            }
            else if (button == Input.Buttons.MIDDLE)
            {
                Grid g = Funcs.getGridOnMouse();
                if (g != null && g.opened == true && g.bombsNear >= 1)
                {
                    // Check If Condition Met
                    int totalFlags = 0;
                    for (int x2 = Math.max(1,g.gridX - 1); x2 <= Math.min(Vars.boardWidth,g.gridX + 1); x2++)
                    {
                        for (int y2 = Math.max(1,g.gridY - 1); y2 <= Math.min(Vars.boardHeight,g.gridY + 1); y2++)
                        {
                            if (x2 == g.gridX && y2 == g.gridY)
                                continue;
                            if (Vars.grids[x2][y2].flagged)
                                totalFlags++;
                        }
                    }
                    if (totalFlags == g.bombsNear)
                    {
                        for (int x2 = Math.max(1,g.gridX - 1); x2 <= Math.min(Vars.boardWidth,g.gridX + 1); x2++)
                        {
                            for (int y2 = Math.max(1,g.gridY - 1); y2 <= Math.min(Vars.boardHeight,g.gridY + 1); y2++)
                            {
                                if (x2 == g.gridX && y2 == g.gridY)
                                    continue;
                                if (!Vars.grids[x2][y2].flagged)
                                    Funcs.BFSOpenFrom(Vars.grids[x2][y2]);
                            }
                        }
                        if (Vars.gameState == 0 && Funcs.checkIfWon())
                        {
                            Funcs.win();
                        }
                    }
                }
            }
        }
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(int amount) {
        return false;
    }
}
