package com.minesweepergame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.util.Collections;


public class MenuScene implements Screen {

    public Stage stage;
    public final Label scoreBoardLabel;

    public MenuScene()
    {
        Vars.menuScene = this;
        Vars.loadScoreboard();
        Vars.init();
        Textures.init();
        stage = new Stage(new ScreenViewport());

        TextButton newGameButton = new TextButton("New Game",Vars.skin);
        newGameButton.setPosition(600 - 32,224);
        newGameButton.setSize(150,50);

        TextButton clearScoreboardButton = new TextButton("Clear Scoreboard",Vars.skin);
        clearScoreboardButton.setPosition(600 - 32,224 - 64);
        clearScoreboardButton.setSize(150,50);

        final TextField boardWidthField = new TextField("9",Vars.skin);
        final TextField boardHeightField = new TextField("9",Vars.skin);
        boardWidthField.setPosition(400 + 64,224 + 32 * 3);
        boardWidthField.setSize(48,24);
        boardWidthField.setTextFieldFilter(new DigitFilter());
        boardWidthField.setVisible(false);
        boardHeightField.setVisible(false);
        boardHeightField.setTextFieldFilter(new DigitFilter());
        boardHeightField.setPosition(400 + 64,224 + 32 * 3 - 24);
        boardHeightField.setSize(48,24);

        final Label boardWidthLabel = new Label("Width",Vars.skin);
        final Label boardHeightLabel = new Label("Height",Vars.skin);
        boardWidthLabel.setVisible(false);
        boardHeightLabel.setVisible(false);
        boardWidthLabel.setPosition(400,224 + 32 * 3);
        boardHeightLabel.setPosition(400,224 + 32 * 3 - 24);

        scoreBoardLabel = new Label("Scoreboard : \n",Vars.skin,"title");
        scoreBoardLabel.setPosition(800, 224 + 32 * 3 - 24);

        ScrollPane scrollPane = new ScrollPane(scoreBoardLabel);
        scrollPane.setBounds(800, 0,470,400); //This should be the bounds of the scroller and the scrollable content need to be inside this
        scrollPane.layout();
        scrollPane.setTouchable(Touchable.enabled);


        final CheckBox beginnerCheckBox = new CheckBox(" Beginner", Vars.skin);
        final CheckBox intermediateCheckBox = new CheckBox(" Intermediate", Vars.skin);
        final CheckBox expertCheckBox = new CheckBox(" Expert", Vars.skin);
        final CheckBox customModeCheckBox = new CheckBox(" Custom Mode ?", Vars.skin);

        newGameButton.addListener( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (beginnerCheckBox.isChecked())
                {
                    Vars.bombCount = 10;
                    Vars.boardHeight = 9;
                    Vars.boardWidth = 9;
                    Vars.difficulty = "Beginner";
                }
                if (intermediateCheckBox.isChecked())
                {
                    Vars.bombCount = 40;
                    Vars.boardHeight = 16;
                    Vars.boardWidth = 16;
                    Vars.difficulty = "Intermediate";
                }
                if (expertCheckBox.isChecked())
                {
                    Vars.bombCount = 99;
                    Vars.boardHeight = 16;
                    Vars.boardWidth = 30;
                    Vars.difficulty = "Expert";
                }
                if (customModeCheckBox.isChecked())
                {
                    Vars.boardHeight = Integer.parseInt(boardHeightField.getText());
                    Vars.boardWidth = Integer.parseInt(boardWidthField.getText());
                    Vars.boardHeight = Math.min(Vars.boardHeight,16);
                    Vars.boardWidth = Math.min(Vars.boardWidth,30);
                    Vars.boardWidth = Math.max(Vars.boardWidth,1);
                    Vars.boardHeight = Math.max(Vars.boardHeight,1);

                    // If not big enough, make it bigger
                    boolean lastHeight = false;
                    while (Vars.boardWidth * Vars.boardHeight <= 9)
                    {
                        if (lastHeight)
                            Vars.boardWidth++;
                        else
                            Vars.boardHeight++;
                        lastHeight = !lastHeight;
                    }

                    if (beginnerCheckBox.isChecked())
                    {
                        Vars.bombCount = (int)((Vars.boardHeight * Vars.boardWidth) * (10f / 81f));
                    }
                    if (intermediateCheckBox.isChecked())
                    {
                        Vars.bombCount = (int)((Vars.boardHeight * Vars.boardWidth) * (40f / 256f));
                    }
                    if (expertCheckBox.isChecked())
                    {
                        Vars.bombCount = (int)((Vars.boardHeight * Vars.boardWidth) * (99f / 480f));
                    }
                }
                Vars.clearVars();
                Vars.inputMultiplexer.removeProcessor(stage);
                Vars.game.setScreen( new GameScene() );
            };
        });

        clearScoreboardButton.addListener( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Vars.wins.clear();
                adjustScoreboard();
            };
        });

        ButtonGroup pieceChoiceGroup = new ButtonGroup<CheckBox>();



        pieceChoiceGroup.add(intermediateCheckBox);
        pieceChoiceGroup.add(beginnerCheckBox);
        pieceChoiceGroup.add(expertCheckBox);
        pieceChoiceGroup.setMaxCheckCount(1);
        pieceChoiceGroup.setMinCheckCount(1);
        pieceChoiceGroup.setUncheckLast(true);
        pieceChoiceGroup.setChecked(" Beginner");

        beginnerCheckBox.setPosition(600,224 + 32 * 4);
        intermediateCheckBox.setPosition(600,224 + 32 * 3);
        expertCheckBox.setPosition(600,224 + 32 * 2);
        customModeCheckBox.setPosition(400,224 + 32 * 4);
        customModeCheckBox.addListener(new ChangeListener() {
            @Override
            public void changed (ChangeEvent event, Actor actor) {
                if (customModeCheckBox.isChecked())
                {
                    boardWidthField.setVisible(true);
                    boardHeightField.setVisible(true);
                    boardWidthLabel.setVisible(true);
                    boardHeightLabel.setVisible(true);
                }
                else
                {
                    boardWidthField.setVisible(false);
                    boardHeightField.setVisible(false);
                    boardWidthLabel.setVisible(false);
                    boardHeightLabel.setVisible(false);
                }
            }
        });

        stage.addActor(newGameButton);
        stage.addActor(beginnerCheckBox);
        stage.addActor(intermediateCheckBox);
        stage.addActor(expertCheckBox);
        stage.addActor(customModeCheckBox);
        stage.addActor(boardWidthField);
        stage.addActor(boardHeightField);
        stage.addActor(boardWidthLabel);
        stage.addActor(boardHeightLabel);
        stage.addActor(scrollPane);
        stage.addActor(clearScoreboardButton);
    }

    @Override
    public void show() {
        Vars.gameState = 1;
        Vars.inputMultiplexer.addProcessor(stage);
        adjustScoreboard();
    }

    public void adjustScoreboard ()
    {
        Collections.sort(Vars.wins,new WinScoreComparator());
        scoreBoardLabel.setText("Scoreboard :\n");
        for (WinScore i : Vars.wins)
        {
            String strDouble = String.format("%.2f", i.time);
            scoreBoardLabel.setText(scoreBoardLabel.getText() + strDouble + "s, " + i.difficulty + " " + i.boardWidth + "x" + i.boardHeight + "\n");
        }
        if (Vars.wins.size() == 0)
            scoreBoardLabel.setText(scoreBoardLabel.getText() + "Empty\n");
//        scoreBoardLabel.setWrap(true);
//        scoreBoardLabel.setWidth(400);
//        scoreBoardLabel.setHeight(scoreBoardLabel.getPrefHeight());
        Vars.saveScoreboard();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor( 186f / 255f, 228 / 255f, 248f / 255f, 1 );
        Gdx.gl.glClear( GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT );
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

        stage.dispose();

    }
}
