package com.minesweepergame;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.particles.renderers.PointSpriteRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class Grid {

    public int gridX, gridY;
    public float x,y;
    public float size;
    public int type;
    public boolean opened = false;
    public int bombsNear;
    public boolean flagged;
    public boolean changeColor;
    public boolean changeColor2;
    public boolean unknown;
    public boolean renderOpened;

    public Grid (float x, float y, float size)
    {
        this.x = x;
        this.y = y;
        this.size = size;
    }

    public void update (float delta)
    {

    }

    public void renderShapes(ShapeRenderer shapeRenderer)
    {

    }

    public void renderSprites (SpriteBatch spriteBatch)
    {
        spriteBatch.setColor(Color.WHITE);
        if (renderOpened)
        {
            if (unknown)
                spriteBatch.draw(Textures.unknownopened,x,y,size,size);
            else
                spriteBatch.draw(Textures.t[0],x,y,size,size);
            return;
        }

        if (opened)
        {
            if (bombsNear >= 0)
            {
                spriteBatch.draw(Textures.t[bombsNear],x,y,size,size);
            }
            else
            {
                if (changeColor)
                    spriteBatch.setColor(Color.RED);
                else if (changeColor2)
                    spriteBatch.setColor(Color.GREEN);
                spriteBatch.draw(Textures.mine,x,y,size,size);
            }
        }
        else if (flagged)
        {
            spriteBatch.draw(Textures.flag,x,y,size,size);
        }
        else if (unknown)
        {
            spriteBatch.draw(Textures.unknown,x,y,size,size);
        }
        else
        {
            spriteBatch.draw(Textures.closed,x,y,size,size);
        }
    }

    public void open ()
    {
        opened = true;
        if (bombsNear == -1)
        {
            changeColor = true;
            Vars.gameState = 1;
            Vars.gameOverText = "You Lost!";
            for (int x = 1; x <= Vars.boardWidth; x++)
            {
                for (int y = 1; y <= Vars.boardHeight; y++)
                {
                    if (Vars.grids[x][y].bombsNear == -1)
                    {
                        Vars.grids[x][y].opened = true;
                        if (Vars.grids[x][y].flagged)
                        {
                            Vars.grids[x][y].changeColor2 = true;
                        }
                    }
                }
            }
        }
    }
}
