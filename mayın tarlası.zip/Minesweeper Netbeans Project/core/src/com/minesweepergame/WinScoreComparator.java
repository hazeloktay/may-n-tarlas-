package com.minesweepergame;

import java.util.Comparator;

public class WinScoreComparator implements Comparator<WinScore> {
    @Override
    public int compare(WinScore o1, WinScore o2) {
        return Float.compare(o1.time,o2.time);
    }
}