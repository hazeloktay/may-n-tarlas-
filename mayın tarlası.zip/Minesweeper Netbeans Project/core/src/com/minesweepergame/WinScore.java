package com.minesweepergame;

public class WinScore {

    public int boardWidth;
    public int boardHeight;
    public float time;
    public String difficulty;
}
