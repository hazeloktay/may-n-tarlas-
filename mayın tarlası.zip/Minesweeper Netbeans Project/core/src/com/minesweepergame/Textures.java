package com.minesweepergame;

import com.badlogic.gdx.graphics.Texture;

public class Textures {

    public static Texture flag;
    public static Texture[] t = new Texture[9];
    public static Texture closed;
    public static Texture mine;
    public static Texture tray;
    public static Texture time;
    public static Texture unknown;
    public static Texture unknownopened;

    public static void init ()
    {
        flag = new Texture("flag.png");
        for (int i = 0; i <= 8; i++)
        {
            t[i] = new Texture(i + ".png");
        }
        closed = new Texture("closed.png");
        mine = new Texture("mine.png");
        tray = new Texture("tray.png");
        time = new Texture("time.png");
        unknown = new Texture("unknown.png");
        unknownopened = new Texture("unknownopened.png");
    }
}
