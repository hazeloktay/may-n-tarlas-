package com.minesweepergame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

import javax.jws.Oneway;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Vars {

    public static SpriteBatch spriteBatch = new SpriteBatch();
    public static ShapeRenderer shapeRenderer = new ShapeRenderer();
    public static int boardWidth = 20;
    public static int boardHeight = 12;
    public static int gridSize = 36;
    public static Grid[][] grids;
    public static int bombCount = 20;
    public static int flaggedCount = 0;
    public static BitmapFont arialFont;
    public static BitmapFont arialFontBig;
    public static Grid firstClickGrid = null;
    public static boolean bfsVisited[][];
    public static LinkedList<Grid> bfsQueue = new LinkedList<Grid>();
    public static InputHandler inputHandler = new InputHandler();
    public static InputMultiplexer inputMultiplexer = new InputMultiplexer();
    public static GameScene gameScene;
    public static MenuScene menuScene;
    public static float gameTime;
    public static String gameOverText = "";
    public static Skin skin;
    public static MinesweeperGame game;
    public static String difficulty;
    public static ArrayList<WinScore> wins = new ArrayList<WinScore>();

    // 0 == PLAYING
    // 1 == WON // LOST
    public static int gameState = 1;

    public static int GameState = 1;

    public static void init ()
    {
        shapeRenderer.setAutoShapeType(true);
        grids = new Grid[boardWidth + 1][boardHeight + 1];
        bfsVisited = new boolean[boardWidth + 1][boardHeight + 1];

        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("arial.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter parameter = new FreeTypeFontGenerator.FreeTypeFontParameter();
        parameter.size = 16;
        arialFont = generator.generateFont(parameter);
        generator.dispose();

        FreeTypeFontGenerator generator2 = new FreeTypeFontGenerator(Gdx.files.internal("arial.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter parameter2 = new FreeTypeFontGenerator.FreeTypeFontParameter();
        parameter2.size = 48;
        arialFontBig = generator2.generateFont(parameter2);
        generator2.dispose();

        inputMultiplexer.addProcessor(inputHandler);
        Gdx.input.setInputProcessor(inputMultiplexer);

        skin = new Skin(Gdx.files.internal("shade/skin/uiskin.json"));
    }

    public static void clearVars ()
    {
        grids = new Grid[boardWidth + 1][boardHeight + 1];
        bfsVisited = new boolean[boardWidth + 1][boardHeight + 1];
        gameTime = 0;
        firstClickGrid = null;
        bfsQueue.clear();
        flaggedCount = 0;
    }

    public static void loadScoreboard ()
    {
        try {
            BufferedReader br = new BufferedReader(new FileReader(System.getenv("APPDATA") + "/Minesweeper.txt"));
            String line;
            while ((line = br.readLine()) != null)
            {
                String[] tmp = line.split(",");
                WinScore ws = new WinScore();
                ws.boardWidth = Integer.parseInt(tmp[0]);
                ws.boardHeight = Integer.parseInt(tmp[1]);
                ws.time = Float.parseFloat(tmp[2]);
                ws.difficulty = tmp[3];
                Vars.wins.add(ws);
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public static void saveScoreboard()
    {
        try
        {
            System.out.println("Saving");
            PrintWriter out = new PrintWriter(System.getenv("APPDATA") + "/Minesweeper.txt");
            for (WinScore ws : Vars.wins)
            {
                out.print(ws.boardWidth + "," + ws.boardHeight + "," + ws.time + "," + ws.difficulty);
                out.println();
            }
            out.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

}
