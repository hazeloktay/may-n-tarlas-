package com.minesweepergame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;

import java.awt.*;

public class GameScene implements Screen {


    public GameScene()
    {
        Vars.gameScene = this;
        // Preparing Grids
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                Grid g = new Grid((Gdx.graphics.getWidth() / 2) - Vars.boardWidth * Vars.gridSize / 2 + (x - 1) * Vars.gridSize,Vars.gridSize + (y - 1) * Vars.gridSize,Vars.gridSize);
                g.gridX = x;
                g.gridY = y;
                Vars.grids[x][y] = g;
            }
        }
        Vars.gameState = 0;
    }

    public void placeBombs ()
    {
        // Placing Bombs
        for (int i = 1; i <= Math.min(Vars.boardHeight * Vars.boardWidth - 9, Vars.bombCount); i++)
        {
            Vector2 v = Funcs.getRandomNonBombCoords();
            Vars.grids[(int)v.x][(int)v.y].type = 1;
        }

        // Bomb Counts
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                Grid g = Vars.grids[x][y];
                if (g.type == 1)
                {
                    g.bombsNear = -1;
                    continue;
                }

                for (int x2 = Math.max(1,g.gridX - 1); x2 <= Math.min(Vars.boardWidth,g.gridX + 1); x2++)
                {
                    for (int y2 = Math.max(1,g.gridY - 1); y2 <= Math.min(Vars.boardHeight,g.gridY + 1); y2++)
                    {
                        if (g.gridX == x2 && g.gridY == y2)
                            continue;
                        if (Vars.grids[x2][y2].type == 1)
                            g.bombsNear++;
                    }
                }
            }
        }
    }

    @Override
    public void show() {

    }

    public void update (float delta)
    {
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                Vars.grids[x][y].renderOpened = false;
            }
        }

        if (Vars.gameState == 0)
        {
            if (Vars.firstClickGrid != null)
                Vars.gameTime += delta;

            for (int x = 1; x <= Vars.boardWidth; x++)
            {
                for (int y = 1; y <= Vars.boardHeight; y++)
                {
                    Vars.grids[x][y].update(delta);
                }
            }
            if (Gdx.input.isButtonPressed(Input.Buttons.MIDDLE))
            {
                Grid g = Funcs.getGridOnMouse();
                if (g != null)
                {
                    if (g.opened == false && g.flagged == false)
                        g.renderOpened = true;

                    for (int x2 = Math.max(1,g.gridX - 1); x2 <= Math.min(Vars.boardWidth,g.gridX + 1); x2++)
                    {
                        for (int y2 = Math.max(1,g.gridY - 1); y2 <= Math.min(Vars.boardHeight,g.gridY + 1); y2++)
                        {
                            if (x2 == g.gridX && y2 == g.gridY)
                                continue;
                            if (!Vars.grids[x2][y2].opened && !Vars.grids[x2][y2].flagged)
                                Vars.grids[x2][y2].renderOpened = true;
                        }
                    }
                }
            }
        }
    }

    @Override
    public void render(float delta) {
        update(delta);
        Gdx.gl.glClearColor( 186f / 255f, 228 / 255f, 248f / 255f, 1 );
        Gdx.gl.glClear( GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT );

        Vars.shapeRenderer.begin();
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                Vars.grids[x][y].renderShapes(Vars.shapeRenderer);
            }
        }
        Vars.shapeRenderer.end();

        Vars.spriteBatch.begin();
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                Vars.grids[x][y].renderSprites(Vars.spriteBatch);
            }
        }

        Vars.spriteBatch.setColor(Color.WHITE);

        Vars.spriteBatch.draw(Textures.mine,0,Gdx.graphics.getHeight() - 64,64,64);
        Vars.spriteBatch.draw(Textures.tray,64,Gdx.graphics.getHeight() - 64,128,64);
        Vars.arialFontBig.setColor(new Color(0.6f,0f,0f,1f));
        Vars.arialFontBig.draw(Vars.spriteBatch,(Vars.bombCount - Vars.flaggedCount) + "",32 + 64 + 8,Gdx.graphics.getHeight() - 16);

        Vars.spriteBatch.draw(Textures.time,Gdx.graphics.getWidth() - 128 - 64,Gdx.graphics.getHeight() - 64,64,64);
        Vars.spriteBatch.draw(Textures.tray,Gdx.graphics.getWidth() - 64 - 64,Gdx.graphics.getHeight() - 64,128,64);
        Vars.arialFontBig.setColor(new Color(0f,0.6f,0f,1f));
        Vars.arialFontBig.draw(Vars.spriteBatch,(int)Vars.gameTime + "",Gdx.graphics.getWidth() - 64 - 64 + 16,Gdx.graphics.getHeight() - 16);

        if (Vars.gameState == 1)
        {
            if (Vars.gameOverText == "You Lost!")
                Vars.arialFontBig.setColor(new Color(0.6f,0f,0f,1f));
            else
                Vars.arialFontBig.setColor(new Color(0f,0.6f,0f,1f));
            Vars.arialFont.setColor(Color.BLACK);
            Vars.arialFontBig.draw(Vars.spriteBatch,Vars.gameOverText,32 + 64 + 384 + 32 + 16,Gdx.graphics.getHeight() - 128 + 32 + 64 + 16);
            Vars.arialFont.draw(Vars.spriteBatch,"Press R to try again, press M for menu.",32 + 64 + 384 + 32 - 10,Gdx.graphics.getHeight() - 128 + 32 + 16);
        }
        Vars.spriteBatch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
