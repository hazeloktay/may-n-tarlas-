package com.minesweepergame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import org.w3c.dom.css.Rect;

import java.util.Iterator;

public class Funcs {

    public static Rectangle getMouseRect ()
    {
        Rectangle rect = new Rectangle(Gdx.input.getX(),Gdx.graphics.getHeight() - Gdx.input.getY(),1,1);
        return rect;
    }

    public static Vector2 getRandomNonBombCoords ()
    {
        int x = MathUtils.random(1,Vars.boardWidth);
        int y = MathUtils.random(1,Vars.boardHeight);
        while (Vars.grids[x][y].type == 1 || isNeighborOfIt(Vars.grids[x][y], Vars.firstClickGrid))
        {
            x = MathUtils.random(1,Vars.boardWidth);
            y = MathUtils.random(1,Vars.boardHeight);
        }
        return new Vector2(x,y);
    }

    public static boolean isNeighborOfIt (Grid g1, Grid g)
    {
        for (int x2 = Math.max(1,g.gridX - 1); x2 <= Math.min(Vars.boardWidth,g.gridX + 1); x2++)
        {
            for (int y2 = Math.max(1,g.gridY - 1); y2 <= Math.min(Vars.boardHeight,g.gridY + 1); y2++)
            {
                if (x2 == g1.gridX && y2 == g1.gridY)
                    return true;
            }
        }
        return false;
    }

    public static Grid getGridOnMouse ()
    {
        Rectangle r1 = getMouseRect();
        Rectangle r2 = new Rectangle(0,0,0,0);
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                r2.set(Vars.grids[x][y].x,Vars.grids[x][y].y,Vars.grids[x][y].size,Vars.grids[x][y].size);
                if (r1.overlaps(r2))
                    return Vars.grids[x][y];
            }
        }
        return null;
    }

    public static void win ()
    {
        Vars.gameState = 1;
        Vars.gameOverText = "You Won!";
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                if (Vars.grids[x][y].bombsNear == -1)
                {
                    if (Vars.grids[x][y].flagged == false)
                    {
                        Vars.grids[x][y].flagged = true;
                        Vars.flaggedCount++;
                    }
                }
            }
        }
        WinScore ws = new WinScore();
        ws.boardHeight = Vars.boardHeight;
        ws.boardWidth = Vars.boardWidth;
        ws.difficulty = Vars.difficulty;
        ws.time = Vars.gameTime;
        Vars.wins.add(ws);
    }

    public static void BFSOpenFrom (Grid grid)
    {
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                Vars.bfsVisited[x][y] = false;
            }
        }
        Vars.bfsQueue.clear();

        Vars.bfsVisited[grid.gridX][grid.gridY] = true;
        Vars.bfsQueue.add(grid);

        while (Vars.bfsQueue.size() != 0)
        {
            Grid g = Vars.bfsQueue.poll();
            if (g.flagged)
                continue;
            g.open();
            if (g.bombsNear == 0)
            {
                for (int x2 = Math.max(1,g.gridX - 1); x2 <= Math.min(Vars.boardWidth,g.gridX + 1); x2++)
                {
                    for (int y2 = Math.max(1,g.gridY - 1); y2 <= Math.min(Vars.boardHeight,g.gridY + 1); y2++)
                    {
                        if (Vars.bfsVisited[x2][y2])
                            continue;
                        Vars.bfsQueue.add(Vars.grids[x2][y2]);
                        Vars.bfsVisited[x2][y2] = true;
                    }
                }
            }
        }
    }

    public static boolean checkIfWon ()
    {
        int closedCount = 0;
        for (int x = 1; x <= Vars.boardWidth; x++)
        {
            for (int y = 1; y <= Vars.boardHeight; y++)
            {
                if (Vars.grids[x][y].opened == false)
                    closedCount++;
            }
        }
        if (closedCount == Vars.bombCount)
            return true;
        return false;
    }


}
